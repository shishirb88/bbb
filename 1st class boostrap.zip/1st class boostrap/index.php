<html>
<head>
<title> shishir </title>
<link rel="stylesheet" type="text/css" href="style.css">
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
</head>
<body>
	<!-- Header Start -->
	<div class="banner"><img src="image/student/Mehadi.jpg"></div>
	<!-- Header End -- >
	<!-- menu Start -->
	<div class="menu">
		<ul>
			<li><a href="index.html"> Home </a></li>
			<li><a href="about.html"> About </a></li>
			<li><a href="gallary.html"> Gallary </a></li>
			<li><a href="contact.html"> contact </a></li>
		</ul>
	</div>
	<div class="about" >The educational publishing and educational assessment communities have long been aware of the negative impact of unreliable TTS pronunciation. Mismatches between how content is spoken by TTS and how it should be spoken according to pedagogical practice are well known to confuse and otherwise hamper the student experience.</div>

	<footer>
		&copy; all right Resarved
	</footer>
</body>
</html>